COBBLEVERSE Soundtrack
Version 1, 30 April 2025


📜 CREDITS 📜

💿 5
   - Author: Zame
   - Title: Lavender Town
   - Link: https://www.youtube.com/watch?v=pMEaxpZBjh8

🎵 Alpha
   - Author: Zame
   - Title: Ending Credits
   - Link: https://www.youtube.com/watch?v=9Zq4YQWnaOI

🎵 Ancestry
   - Author: Pokestir
   - Title: Route 110
   - Link: https://www.youtube.com/watch?v=0jyuSwp1QgY

💿 Chirp
   - Author: Zame
   - Title: Pokémon Center
   - Link: https://www.youtube.com/watch?v=d8hghYqHjcQ

🎵 Clark
   - Author: Zame
   - Title: Skyarrow Bridge
   - Link: https://www.youtube.com/watch?v=BkuotsjIzEQ

🎵 Comforting Memories
   - Author: Zame
   - Title: Oldale Town
   - Link: https://www.youtube.com/watch?v=nGvn51y11tk

🎵 Echo in the Wind
   - Author: Pokestir
   - Title: Route 209
   - Link: https://www.youtube.com/watch?v=PCxdSSNXKxs

🎵 Key
   - Author: Zame
   - Title: Pallet Town
   - Link: https://www.youtube.com/watch?v=2BQsxO-wUa4

💿 Mall
   - Author: Zame
   - Title: Poké Mart
   - Link: https://www.youtube.com/watch?v=IH94Pse2up4

💿 Mellohi
   - Author: Zame
   - Title: Lullaby
   - Link: https://www.youtube.com/watch?v=cjtb_zfUsLI

🎵 One More Day
   - Author: Pokestir
   - Title: Lumiose City
   - Link: https://www.youtube.com/watch?v=KyZfyvy0O8M

🎵 Oxygene
   - Author: Zame
   - Title: Littleroot Town
   - Link: https://www.youtube.com/watch?v=kSkWCcBQvsc

💿 Precipice
   - Author: Zame
   - Title: Lavender Town
   - Link: https://www.youtube.com/watch?v=oL4uM5x_Dsg

💿 Relic
   - Author: Pokestir
   - Title: Oak's Laboratory
   - Link: https://www.youtube.com/watch?v=9atHevG0pQI

🎵 Stand Tall
   - Author: Pokestir
   - Title: Kalos Region Theme
   - Link: https://www.youtube.com/watch?v=eimRgjUPnEE

💿 Stal
   - Author: Pokestir
   - Title: Game Corner
   - Link: https://www.youtube.com/watch?v=u7oIcHnXp8Y

💿 Strad
   - Author: Pokestir
   - Title: Radio March
   - Link: https://www.youtube.com/watch?v=jrMUHZ5KO4o

🎵 The End
   - Author: Pokestir
   - Title: Battle! Johto Gym Leader
   - Link: https://www.youtube.com/watch?v=DoLV17VEc14

💿 Wait
   - Author: Pokestir
   - Title: Bike Theme
   - Link: https://www.youtube.com/watch?v=YfWWNgI1rK0

💿 Ward
   - Author: Zame
   - Title: Pokémon Tower
   - Link: https://www.youtube.com/watch?v=3rllCRyidQc

🎵 Wending
   - Author: Pokestir
   - Title: Surfing
   - Link: https://www.youtube.com/watch?v=9QrEPVTNTRc




📻 Champion - Battle
   - Author: Zame
   - Link: https://www.youtube.com/watch?v=LeypWNPDm4k

📻 Gym Battle - Johto
   - Author: Zame
   - Link: https://www.youtube.com/watch?v=VKIkDnZThLo

📻 Gym Battle - Sinnoh
   - Author: Pokestir
   - Link: https://www.youtube.com/watch?v=dnJpRQzLgmE

📻 Team Rocket - Battle
   - Author: Pokestir
   - Link: https://www.youtube.com/watch?v=d3umh4UMdHg

📻 Team Rocket Admin - Battle
   - Author: Pokestir
   - Link: https://www.youtube.com/watch?v=NBqIvDZ3Jn4

📻 Trainer Battle - Kanto
   - Author: Pokestir
   - Link: https://www.youtube.com/watch?v=CJw_e1tR3yk

📻 Wild Battle - Hoenn
   - Author: Zame
   - Link: https://www.youtube.com/watch?v=9WhBomyrvcQ

📻 Wild Battle - Johto
   - Author: Pokestir
   - Link: https://www.youtube.com/watch?v=V03_WEw1MzU

📻 Wild Battle - Kanto
   - Author: Pokestir
   - Link: https://www.youtube.com/watch?v=8m11kUkBo0g

📻 Wild Battle - Sinnoh
   - Author: Pokestir
   - Link: https://www.youtube.com/watch?v=P9NPNlq4ZvA



🖼️ Music Notification Albums: https://www.deviantart.com/pkmnicons



This soundtrack was made to work with the COBBLEVERSE modpack.
All content was used with permission, and full credit goes to the original creators.