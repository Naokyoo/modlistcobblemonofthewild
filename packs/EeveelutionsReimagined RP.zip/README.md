📦 Eeveelutions Reimaged – License & Usage

📜 License

This resource pack is licensed under:
Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0)
🔗 View Full License : https://creativecommons.org/licenses/by-nc/4.0/)

⚠️ Note: This license only applies to the custom animations included in this resource pack.
The models used are provided by the Cobblemon Team and are freely available under their own license.

✅ You May:

Use it privately
Use it on Servers
Use it in videos, streams, or screenshots, as long as proper credit is given “Eeveelutions Reimaged” by SK4N
Share the pack, as long as:

  It remains unmodified
  Proper attribution is provided
  It is not used commercially

❌ You May Not:

Use this pack commercially (e.g., sell it, use in paid servers, include behind a paywall)
Use it without credit
Redistribute modified versions without permission
Include it in modpacks or server packs that are monetized

ℹ️ Attribution Requirement

If you use or showcase this resource pack, please include the following credit:

> Eevvelutions Reimaged – by SK4N
> Licensed under [CC-BY-NC 4.0] https://creativecommons.org/licenses/by-nc/4.0/

📧 Contact

For questions or special permission requests:

> 📩 Discord: SK4N

