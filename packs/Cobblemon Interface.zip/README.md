# Cobblemon Interface

[![Modrinth](https://cdn.jsdelivr.net/npm/@intergrav/devins-badges@3/assets/cozy/available/modrinth_vector.svg)](https://modrinth.com/resourcepack/cobblemon-interface)
[![CurseForge](https://cdn.jsdelivr.net/npm/@intergrav/devins-badges@3/assets/cozy/available/curseforge_vector.svg)](https://curseforge.com/minecraft/texture-packs/cobblemon-interface)

---

Makes Minecraft's interface and sounds fit the [Cobblemon](https://modrinth.com/mod/cobblemon) mod aesthetics.

### Mod Support

| Mod | Cobblemon Interface |
|----:|:--------------------|
| [Cobblemon](https://modrinth.com/mod/cobblemon) | >= v1.1 |
| [Fabric API](https://modrinth.com/mod/fabric-api) | >= v0.7 |
| [Mod Menu](https://modrinth.com/mod/modmenu) | >= v0.1 |
| [Raised](https://modrinth.com/mod/raised) | >= v1.5.1 |

### Recommendations

[![](https://vinnystalck.gitlab.io/minecraft-badges/badges/respackopts/cozy-recommends.png)](https://modrinth.com/mod/respackopts)

⭐️: Highly Recommended |
📁: Resourcepack |
🛠️: Mod

- 🛠️⭐️ **[Respackopts](https://modrinth.com/mod/respackopts)**: Allows you to customize various aspects of the resourcepack in-game.
- 📁⭐️ **[Cobblemon Interface: Modded](https://modrinth.com/project/cobblemon-interface-modded)**: Adds support for many mods;
- 🛠️ **[Raised](https://modrinth.com/mod/raised)**: Moves the hotbar so it doesn't crop the texture;
- 📁 **[Fancy Item Renders](https://modrinth.com/resourcepack/fancy-item-renders)**: Tilts item displays so that items that have long textures (swords for example) doesn't look off with the rounded item slots.


### Minecraft Pack Version Compatibility

[Minecraft pack format](https://minecraft.wiki/w/Pack_format)

| Minecraft Pack | Minecraft | Cobblemon Interface |
|---------------:|:---------:|:--------------------|
| 9              | <= 1.19.2 | <= v0.7             |
| 15             | >= 1.20   | >= v0.8             |
| 34             | >= 1.21   | >= v1.4             |


## More

[![Gitlab](https://cdn.jsdelivr.net/npm/@intergrav/devins-badges@3/assets/compact/available/gitlab_vector.svg)](https://gitlab.com/VinnyStalck/cobblemon-interface)
[![Ko-fi](https://cdn.jsdelivr.net/npm/@intergrav/devins-badges@3/assets/compact/donate/kofi-singular_vector.svg)](https://ko-fi.com/M4M5K4BDR)

[![Discord](https://cdn.jsdelivr.net/npm/@intergrav/devins-badges@3.1.0/assets/compact/social/discord-singular_vector.svg)](https://discord.com/channels/934267676354834442/1091579923396820992)

You need to be in the [Official Cobblemon Discord Server🔗](https://discord.gg/cobblemon).
